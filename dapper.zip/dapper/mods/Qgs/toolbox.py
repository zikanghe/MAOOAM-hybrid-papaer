# -*- coding: utf-8 -*-
"""
Created on Tue Jan 24 21:39:43 2023

@author: Zikang
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jan 24 21:27:53 2023

@author: Zikang
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jan 23 19:19:08 2023

@author: Zikang
"""


# load toolbox
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.layers import Input, BatchNormalization, Dense
from tensorflow.keras import regularizers
from tensorflow.keras.models import Model
import matplotlib.pyplot as plt
import netCDF4 as nc
import pandas as pd
import joblib





def cal_p(long,latg):
#ind = 260
#ind2 = 190
		nf = nc.Dataset('F:/data_assimation/NORCPM/test_1/main_code/data/analysisforecast.nc','r')
		lon = nf.variables['plon'][:].data
		lat = nf.variables['plat'][:].data

		aicec = nf.variables['aicen'][:].data
		ficec = nf.variables['ficen'][:].data

		aicet = nf.variables['aicet'][:].data
		ficet = nf.variables['ficet'][:].data

		aT = nf.variables['atemp'][:].data
		fT = nf.variables['ftemp'][:].data

		aS = nf.variables['asalt'][:].data
		fS = nf.variables['fsalt'][:].data


		aicec_exp=np.mean(aicec[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		ficec_exp=np.mean(ficec[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		aicet_exp=np.mean(aicet[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		ficet_exp=np.mean(ficet[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		aT_exp=np.mean(aT[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		fT_exp=np.mean(fT[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		aS_exp=np.mean(aS[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		fS_exp=np.mean(fS[long-1:long+2,latg-1:latg+2,:],axis=(1,0))
		#d = np.where(aicec_exp==1)
		aicec_exp[aicec_exp>=1]=1

		scaler_x = StandardScaler()
		scaler_y = StandardScaler()

		yy = np.zeros((216,2))
		xx = np.zeros((216,4))
		xx_train = np.zeros((180,4))
		yy_train = np.zeros((180,2))
		xx_val = np.zeros((12,4))
		yy_val = np.zeros((12,2))
		xx = np.zeros((216,4))
		if pd.isnull(fT_exp[0]):
			xx_train[xx_train==0] = np.nan
			yy_train[yy_train==0] = np.nan
			xx_val[xx_val==0] = np.nan
			yy_val[yy_val==0] = np.nan
			return xx_train,yy_train,xx_val,yy_val
		else:
			yy[:,0]= aicec_exp-ficec_exp
			yy[:,1]= aicet_exp-ficet_exp
			xx[:,0]= fT_exp
			xx[:,1]= fS_exp
			xx[:,2]= ficec_exp
			xx[:,3]= ficet_exp

#xx = np.delete(xx, (d), axis=0)
#yy = np.delete(yy, (d), axis=0)

			scaler_x.fit(xx);
			scaler_y.fit(yy);
			xx_train = xx[0:180,:]
			yy_train = yy[0:180]

			xx_val = xx[180:192,:]
			yy_val = yy[180:192]
			return xx_train,yy_train,xx_val,yy_val




def buildmodel_dense(archi= [(100, 'relu'), (50, 'relu')], m=4, reg=1e-4, batchlayer={0}):

	    inputs = Input(shape=(m,))
	    if 0 in batchlayer:
			      x = BatchNormalization()(inputs)
	    else:
			      x = inputs
	    for i, (nneur, activ) in enumerate(archi):
	        if i+1 in batchlayer:
	            x = BatchNormalization()(x)
	        x = Dense(nneur, activation=activ)(x)
	    output = Dense(2, activation='linear', kernel_regularizer=regularizers.l2(reg))(x)
	    return Model(inputs, output)



def train(ind,ind2):
		xx_train,yy_train,xx_val,yy_val = cal_p(ind,ind2)
		if pd.isnull(xx_train[0,0]):
			return
		else:
			kw_modelargs = {
				'archi': [(100, 'relu'), (50, 'relu')],
				'm':4,
				'reg': 1e-4,
				'batchlayer':{0}
				}
			model = buildmodel_dense(**kw_modelargs)

			callback =tf.keras.callbacks.EarlyStopping(
			monitor="val_loss",
			min_delta=0,
			patience=50,
			verbose=0,
			mode="auto",
			baseline=None,
			restore_best_weights=True,
			)

			opt = tf.keras.optimizers.Adam(learning_rate=0.0015)
			model.compile(loss='mse', optimizer=opt)
			history11 = model.fit(scaler_x.transform(xx_train),scaler_y.transform(yy_train),
	                    epochs=100, batch_size=256,callbacks=[callback],
	                    validation_data=(scaler_x.transform(xx_val),scaler_y.transform(yy_val)))
			model.save_weights('../data/weight_ice_'+str(ind)+'_'+str(ind2)+'.h5')
			joblib.dump(scaler_x,'../data/scalerx_ice_'+str(ind)+'_'+str(ind2)+'.pkl')
			joblib.dump(scaler_y,'../data/scalery_ice_'+str(ind)+'_'+str(ind2)+'.pkl')
			return





