
Examples
========

Some basic examples are available in this section:

.. toctree::
   :maxdepth: 1

   examples/RP.rst
   examples/DDV
   examples/Lietal
   examples/diffeq
   examples/tgls
   examples/VSPD
   examples/manual