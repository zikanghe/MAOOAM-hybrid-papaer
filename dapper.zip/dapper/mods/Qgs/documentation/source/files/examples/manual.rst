
.. include:: manual_basis.rst
    :start-line: 13
