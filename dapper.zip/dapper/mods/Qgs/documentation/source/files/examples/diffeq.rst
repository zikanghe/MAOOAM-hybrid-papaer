
.. include:: diffeq_example.rst
    :start-line: 13
