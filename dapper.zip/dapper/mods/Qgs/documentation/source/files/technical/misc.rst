
Miscellaneous modules
=====================

`Fourre-tout` place of the model code.

.. automodule:: qgs.plotting.util
    :members:
