
Functions module
================

The functions module contains utility functions used by the model, as well as some high-level functions to handle it.

.. automodule:: qgs.functions.sparse_mul
    :members:

.. automodule:: qgs.functions.tendencies
    :members:

.. automodule:: qgs.functions.util
    :members:
