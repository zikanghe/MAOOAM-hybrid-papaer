
Tensors module
==============

Module holding the model's tendencies tensor encoding each of their additive terms.

.. automodule:: qgs.tensors.qgtensor
    :show-inheritance:
    :members:
